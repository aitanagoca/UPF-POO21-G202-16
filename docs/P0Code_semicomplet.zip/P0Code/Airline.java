public class Airline {
    private String name;

    public Airline( String initName ) {
        name = initName;
    }

    public void printName() {
        System.out.println( name );
    }
}


package bookstore;

import java.util.Currency;

public interface StockInterface {
	public String getBooktitle();
	public int numberOfCopies();
	public void addCopies( int numberOfCopies );
	public void removeCopies( int numberOfCopies );
	public double totalPrice();
	
	// Afegim els dos mètodes que farem servir a la classe Stock.
	public Currency getCurrency();
	public Book getBook();
}

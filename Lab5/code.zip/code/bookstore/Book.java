package bookstore;
import java.util.Date;

public class Book {

    // Atributs
    private String title;
    private String author;
    private Date publicationDate;
    private String publicationPlace;
    private long ISBN;

    // Constructor
    public Book( String tlinit, String auinit, Date dtinit, String plinit, long isbn) {
        this.title = tlinit;
        this.author = auinit;
        this.publicationDate = dtinit;
        this.publicationPlace = plinit;
        this.ISBN = isbn;
    }

    // Obtenim el títol d'un llibre.
    public String getTitle() {
        return this.title;
    }

    // Obtenim l'autor d'un llibre.
    public String getAuthor() {
        return this.author;
    }
    
    // Obtenim la data de publicació d'un llibre.
    public Date getPublicationDate() {
        return this.publicationDate;
    }
    
    // Obtenim el lloc de publicació d'un llibre.
    public String getPublicationPlace() {
        return this.publicationPlace;
    }

    // Obtenim el ISBN d'un llibre.
    public long getISBN() {
        return this.ISBN;
    }
}
package bookstore;
import java.util.Currency;

public class Stock implements StockInterface {
    
    // Atributs
    private Book book;
    protected int copies;
    private double price;
    private Currency currency;

    // Constructor
    public Stock( Book book, int copies, double price, Currency currency ) {
        this.book = book;
        this.copies = copies;
        this.price = price;
        this.currency = currency;
    }

    // Obtenim la instància llibre.
    public Book getBook() {
        return this.book;
    }

    // Obtenim el títol del llibre.
    @Override
    public String getBooktitle() {
        return this.book.getTitle();
    }

    // Obtenim el nombre de còpies del llibre.
    @Override
    public int numberOfCopies() {
        return this.copies;
    }

    // Afegim el número de còpies passada per paràmetre al número de còpies d'un llibre.
    @Override
    public void addCopies( int numberOfCopies ) {
        this.copies += numberOfCopies;
    }

    // Eliminem el número de còpies passada per paràmetre al número de còpies d'un llibre, sempre i quan quedin còpies.
    @Override
    public void removeCopies( int numberOfCopies ) {
        if (numberOfCopies > this.copies){
            this.copies = 0;
        }
        else {
            this.copies -= numberOfCopies;
        }
    }

    // Obtenim el preu d'un llibre.
    @Override
    public double totalPrice() {
        return this.price;
    }

    // Obtenim la moneda que farem servir per fer el checkout.
    @Override
    public Currency getCurrency() {
        return this.currency;
    }
}

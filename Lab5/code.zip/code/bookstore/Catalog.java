package bookstore;
import java.util.HashSet;
import java.util.LinkedList;
import java.text.SimpleDateFormat;
import java.util.Currency;
import java.util.Date;

public class Catalog extends BookCollection {
    
    // Atributs
    protected Catalog catalog; 
    
    // Constructor
    
    public Catalog() {
    
        // Crida al constructor de la classe que hereda
        super();
        collection = new HashSet< StockInterface >();
        LinkedList<String[]> books = new LinkedList<String[]>();
        Date date = new Date();
        books = readCatalog("books.xml");
        
        for( int i = 0; i < books.size(); i++ ){
            String[] book_i = books.get(i);

            // Date instance
            try { date = new SimpleDateFormat().parse( book_i[2] ); }   
            catch( Exception e ) {}
            // Convert to long
            long isbn = Long.parseLong( book_i[4] );  
            // Convert to double                  
            double price = Double.parseDouble( book_i[5] );   
            // Currency instance          
            Currency currency = Currency.getInstance( book_i[6] );  
            // Convert to int    
            int copies = Integer.parseInt( book_i[7] );   
            // Es crea el llibre amb els seus paràmetres.              
            Book book = new Book(book_i[0], book_i[1], date, book_i[3], isbn ); 
            // Es crea un stock amb les característiques del llibre que no hem pogut incloure en el llibre.
            Stock stock = new Stock(book, copies, price, currency);             
            collection.add(stock);
        }
    }
}

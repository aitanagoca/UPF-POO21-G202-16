package bookstore;
import java.util.Currency;
import java.util.Locale;

public class ShoppingCart extends BookCollection implements ShoppingCartInterface {
    
    // Atributs
    protected Catalog catalog; 

    // Constructor
    public ShoppingCart( Catalog catalog ) {
        this.catalog = catalog;
    }

    // Obtenim el títol de tots els llibres del catàleg.
    @Override
    public String[] booktitles() {
        return this.catalog.booktitles();
    }

    // Obtenim el nombre de còpies d'un llibre.
    @Override
    public int numberOfCopies( String booktitle ) {
        return this.catalog.numberOfCopies(booktitle);
    }

    // Afegim a la cistella de la compra el número de còpies que volem d'un llibre i les eliminem del catàleg.
    @Override
    public void addCopies(int numberOfCopies, String booktitle) {
        if (catalog.numberOfCopies(booktitle)-numberOfCopies >= 0 ){
            catalog.removeCopies(numberOfCopies, booktitle);
            for(StockInterface element: catalog.collection){
                if(element.getBooktitle().equals(booktitle)){ 
                    StockInterface stock_true_false = getStock(booktitle);
                    if (stock_true_false == null){
                        Book book = element.getBook();
                        Currency currency = element.getCurrency();
                        double price = element.totalPrice();
                        Stock stock = new Stock(book,numberOfCopies, price, currency);
                        collection.add(stock);
                    }
                    else {
                        stock_true_false.addCopies(numberOfCopies);
                    }
                }
            }
        }
    }

    // Eliminem a la cistella de la compra el número de còpies que volem d'un llibre i les afegim al catàleg.
    @Override
    public void removeCopies(int numberOfCopies, String booktitle) {
        for(StockInterface element: collection){
            if(element.getBooktitle().equals(booktitle)){
                if(element.numberOfCopies()-numberOfCopies >= 0 ){
                    element.removeCopies(numberOfCopies);
                    catalog.addCopies(numberOfCopies, booktitle);
                }
            }
        }
    }

    // Obtenim el preu total de la nostra cistella de la compra.
    @Override
    public double totalPrice(){
        double total = 0;
        for(StockInterface element: collection){
            if(element != null){
                int size = element.numberOfCopies();
                for(int i = 0;i < size; i++){
                    total = total + element.totalPrice();
                }
            }
        }
        return total;
    }

    // Facturem els llibres de la nostra cistella de la compra.
    @Override
    public String checkout(){

        String[] bookTitles = catalog.booktitles();
        StockInterface stock = getStock( bookTitles[0] );
        
        // Creem una instància inicial per fixar una Currency.
        // D'aquesta forma, currency sempre tindrà un valor.
        Currency currency = Currency.getInstance(Locale.GERMANY);

        /* La instància currency canviarà sempre i quan stock no sigui NULL, 
        agafant el valor de l'atribut currency de la classe. */
        if(stock != null) {
            currency = stock.getCurrency();      
        }

        double price = totalPrice();
     
        Payment user = Payment.getTheInstance();
        long VISANumber = 340779810;
        String cardHolder = "Patricia ;)";
        String payment = user.doPayment( VISANumber, cardHolder, price, currency );
        return payment;
    }
    
}

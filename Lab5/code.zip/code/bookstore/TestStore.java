package bookstore;

public class TestStore {
    public static void main(String[] args){ 
        
        // Creem instàncies de Catalog, ShoppingCard i BookStore pel correcte funcionament de  la nostra botiga.
        Catalog catalog = new Catalog();
        ShoppingCart cart = new ShoppingCart( catalog );
        BookStore store = new BookStore( catalog, cart );


    }
}

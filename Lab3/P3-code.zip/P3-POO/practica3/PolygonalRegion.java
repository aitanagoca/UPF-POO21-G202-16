package practica3;

import java.util.LinkedList;
import java.awt.Graphics;
import java.awt.Color;

public class PolygonalRegion extends Region{
    private LinkedList<Point> points;

    // Constructor
    public PolygonalRegion (LinkedList<Point> points){
        this.points = points;
    }

    /* Utilitzant la fórmula de l'àrea proporcionada, calculem l'àrea a partir de les coordenades donades. 
    Tal i com indica la fórmula, iterem amb el valor de j anterior al de i. Finalment, fem el valor absolut (ja que tractem amb àrees positives), i dividim entre 2. */

    public double getArea(){
        double area = 0;
        int n = points.size();
        int j = n - 1;
        for (int i = 0; i < n; i++) {
            area += (points.get(j).getX() + points.get(i).getX()) * (points.get(j).getY() - points.get(i).getY());
            j = i;  
        }
        return Math.abs(area / 2);
    }  

    /* Separem la llista de punts (points) i creem un array de coordenades x i una altre de coordenades y 
    (iterem per introduir un per un els diferents valors de x i y dins l'array).
    Seguidament, podem cridar a la funció de drawPolygon() de Graphics i passar-li per paràmetre els dos arrays 
    creats i el número de punts de la llista de points. 
    Això ens permetrà mostrar per pantalla la regió que nosaltres volguem tot establint el color de vora amb la funció setColor(). */
    
    public void drawPolyRegion(Graphics g) {
        int nPoints = points.size();
        int xPoints[] = new int[nPoints];
        int yPoints[] = new int[nPoints];

        for (int i = 0; i < points.size(); i++) {
            xPoints[i] = (int) points.get(i).getX();
            yPoints[i] = (int) points.get(i).getY();
        }
        g.setColor(Color.black);
        g.drawPolygon(xPoints, yPoints, nPoints);
    }
}

package practica3;

import java.util.LinkedList;
import java.awt.Graphics;

public class Continent {
    private LinkedList<Country> countries;

    // Constructor
    public Continent(LinkedList<Country> countries){
        this.countries = countries;
    }

    /* Cridem a la funció getArea (creada a PolygonalRegion) per, mitjançant la iteració, obtenir l'àrea total d'un continent 
    (el qual està format per diferents regions, és a dir, sumem les àrees de les diferents regions que pertanyen a un mateix continent). */

    public double getTotalArea(){
        double totalArea = 0;
        int m = countries.size();
        for (int i = 0; i < m; i++){
            totalArea += countries.get(i).getArea();
        }
        return totalArea;
    }

    // Cridem a la funció drawCountry() (creada a Country) per, mitjançant la iteració, mostrar per pantalla els diferents països que pertanyen a un mateix continent.

    public void drawContinent(Graphics g) {
        int nCountries = countries.size();
        for(int i = 0; i < nCountries; i++){
            countries.get(i).drawCountry(g);
        }
    }  
}

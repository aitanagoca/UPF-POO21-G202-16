package practica3;

import java.awt.Graphics;

// Creació classe asbtracta Region. -> Una classe abstracta utilitza mètodes abstractes per agrupar el comportament comú.
public abstract class Region {
    
    // Mètodes abstractes. -> Per teoria, han de ser públics.
    public abstract double getArea();
    public abstract void drawPolyRegion(Graphics g);
}

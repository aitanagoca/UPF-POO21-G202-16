package practica3;

import java.util.LinkedList;
import java.awt.Graphics;

public class World {
    private LinkedList<Continent> conts;
    private LinkedList<Ocean> oceans;

    // Constructor
    public World(LinkedList<Continent> conts, LinkedList<Ocean> oceans){
        this.conts = conts;
        this.oceans = oceans;
    }

    /* Cridem a la funció drawContinent() (creada a Continent) i a drawOcean() (creada a Ocean) per, 
    mitjançant la iteració, mostrar per pantalla els diferents continents que pertanyen a un mateix món.*/

    public void drawW(Graphics g) {
        int nContinents = conts.size();
        
        for(int i = 0; i < nContinents; i++){
            conts.get(i).drawContinent(g);
        }
        
        int nOceans = oceans.size();
        
        for(int i = 0; i < nOceans; i++){
            oceans.get(i).drawOcean(g);
        }
    }    
}

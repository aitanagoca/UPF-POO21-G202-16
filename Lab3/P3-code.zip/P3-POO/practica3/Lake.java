package practica3;

import java.util.LinkedList;
import java.awt.Graphics;
import java.awt.Color;

public class Lake {
    private LinkedList<Point> points;

    // Constructor
    
    public Lake (LinkedList<Point> points){
        this.points = points;
    }

    /* Separem la llista de punts (points) i creem un array de coordenades x i una altre de coordenades y 
    (iterem per introduir un per un els diferents valors de x i y dins l'array).
    Seguidament, podem cridar a la funció de drawPolygon() de Graphics i passar-li per paràmetre els dos arrays 
    creats i el número de punts de la llista de points. 
    Això ens permetrà mostrar per pantalla la regió que nosaltres volguem tot establint el color de vora amb la funció setColor(). */

    public void drawLake(Graphics g){
        
        int nPoints = points.size();
        int xPoints[] = new int[nPoints];
        int yPoints[] = new int[nPoints];

        for (int i = 0; i < points.size(); i++) {
            xPoints[i] = (int) points.get(i).getX();
            yPoints[i] = (int) points.get(i).getY();
        }
        
        g.setColor(Color.blue);
        g.drawPolygon(xPoints, yPoints, nPoints);
    }
}


package practica3;

import java.awt.Graphics;

public class City extends GeoPoint{
    private int numhab;

    // Constructor
    public City (double x, double y, String name, int numhab) {
        super(x, y, name);
        this.numhab = numhab;
    }

    // Cridem a la funció drawGP(), creada a GeoPoint, mitjançant un super, ja que estem utilitzant una funció de la superclasse.
    
    public void drawCity(Graphics g) {
        super.drawGP(g);
    }
}

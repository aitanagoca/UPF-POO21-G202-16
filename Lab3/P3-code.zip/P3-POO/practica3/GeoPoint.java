package practica3;

import java.awt.Graphics;
import java.awt.Color;

public class GeoPoint extends Point{
    
    private String name;

    // Constructor
    public GeoPoint (double x, double y, String name) {
        super(x, y);
        this.name = name;
    }

    /* Utilitzem les funcions de Java Graphics setColor(), fillOval() i drawString() per establir el color 
    tant del geomètric point com de la seva etiqueta, per dibuixar un punt i per mostrar per pantalla l'etiqueta 
    del punt, respectivament.*/

    public void drawGP(Graphics g){
        
        int pointX = (int) getX();
        int pointY = (int) getY();
        int width = 10;
        int height = 10;
        
        g.setColor(Color.black);
        g.fillOval(pointX, pointY, width, height);
        g.drawString(name, pointX, pointY-5);
    }
}

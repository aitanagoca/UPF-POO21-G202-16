package practica3;

import java.util.LinkedList;
import java.awt.Graphics;

public class Country extends PolygonalRegion{
    private String name;
    private LinkedList<City> cities;
    private LinkedList<Country> neighbors;
    private LinkedList<Lake> lakes;
    private City capital;

    // Constructor
    
    public Country (LinkedList<Point> points, String name, City capital) {
        super(points);
        this.name = name;
        cities = new LinkedList<City>();
        neighbors = new LinkedList<Country>();
        lakes = new LinkedList<Lake>();
        this.capital = capital;
    }

    // Utilitzem la funció de Java add() per afegir la ciutat passada per paràmetre a la llista de ciutats.
    
    public void addCity (City city) {
        cities.add(city);
    }

    // Utilitzem la funció de Java add() per afegir la country passada per paràmetre a la llista de veïns.
    
    public void addNeighbor (Country country) {
        neighbors.add(country);
    }

    // Utilitzem la funció de Java add() per afegir el lake passat per paràmetre a la llista de lakes.
    
    public void addLake (Lake lake){
        lakes.add(lake);
    }

    /* Cridem a la funció drawCity() (creada a City) per, mitjançant la iteració, mostrar per pantalla 
    les diferents ciutats que pertanyen a un mateix país. Fem el mateix amb lakes. Per últim, Cridem a la funció drawPolyRegion(), 
    creada a PolygonalRegion, mitjançant un super, ja que estem utilitzant una funció de la superclasse.*/
    
    public void drawCountry (Graphics g) {
        
        int nCities = cities.size();
        super.drawPolyRegion(g);

        for(int i = 0; i < nCities; i++){
            cities.get(i).drawCity(g);
        }

        int nLakes = lakes.size();
        
        for(int i = 0; i < nLakes; i++){
            lakes.get(i).drawLake(g);
        }
    }

}
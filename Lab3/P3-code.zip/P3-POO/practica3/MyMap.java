package practica3;

import java.util.LinkedList;

public class MyMap extends javax.swing.JPanel {

    // Atribut
    private World world;

    public MyMap() {
        initComponents();

        // Creació llista de points1 (figura --> hexàgon irregular amb vora negre).
        LinkedList< Point > points1 = new LinkedList< Point >();
        points1.add( new Point( 100, 190 ) );
        points1.add( new Point( 240, 100 ) );
        points1.add( new Point( 380, 190 ) );
        points1.add( new Point( 380, 290 ) );
        points1.add( new Point( 240, 380 ) );
        points1.add( new Point( 100, 290 ) );

        // Creació llista de points2 (figura --> pentàgon irregular amb vora negre).
        LinkedList< Point > points2 = new LinkedList< Point >();
        points2.add( new Point( 500, 540 ) );
        points2.add( new Point( 580, 500 ) );
        points2.add( new Point( 660, 540 ) );
        points2.add( new Point( 610, 700 ) );
        points2.add( new Point( 550, 700 ) );
        
        // Creació llista de points3 (figura --> quadrat amb vora negre).
        LinkedList< Point > points3 = new LinkedList< Point >();
        points3.add( new Point( 500, 100 ) );
        points3.add( new Point( 700, 100 ) );
        points3.add( new Point( 700, 300 ) );
        points3.add( new Point( 500, 300 ) );
        
        // Creació llista de points4 (figura --> triangle equilàter amb vora negre).
        LinkedList< Point > points4 = new LinkedList< Point >();
        points4.add( new Point( 300, 500 ) );
        points4.add( new Point( 375, 630 ) );
        points4.add( new Point( 225, 630 ) );

        // Creació de diferents ciutats amb les seves coordenades, nom i població.

        // Ciutats d'Espanya
        City barcelona = new City(350, 170, "Barcelona", 1620000);
        City pontevedra = new City(170, 140, "Pontevedra", 83029);
        City malaga = new City(235, 375, "Màlaga", 569005);
        City madrid = new City(235, 240, "Madrid", 3223000);

        // Ciutats de Tailandia
        City bangkok = new City(580, 600, "Bangkok", 2161000);
        City huahin = new City(540, 670, "Hua Hin", 513275);
        City pai = new City(540, 515, "Pai", 471941);

        // Ciutats de EEUU
        City miami = new City(525, 295, "Miami", 1472000);
        City washingtonDC = new City(595, 200, "Washington DC", 3645000);

        // Ciutats de Cuba
        City laHabana = new City(295, 580, "La Habana", 821752);
        
        // Creació llista de punts points5 (figura --> rectangle amb vora blava).
        LinkedList< Point > points5 = new LinkedList< Point >();
        points5.add( new Point( 285, 210 ) );
        points5.add( new Point( 360, 210 ) );
        points5.add( new Point( 360, 270 ) );
        points5.add( new Point( 285, 270 ) );

        // Creació llista de punts points6 (figura --> triangle rectangle amb vora blava).
        LinkedList< Point > points6 = new LinkedList< Point >();
        points6.add( new Point( 570, 610 ) );
        points6.add( new Point( 620, 640 ) );
        points6.add( new Point( 545, 640 ) );

        // Creació llista de punts points7 (figura --> hexàgon regular amb vora blava).
        LinkedList< Point > points7 = new LinkedList< Point >();
        points7.add( new Point( 520, 540 ) );
        points7.add( new Point( 550, 525 ) );
        points7.add( new Point( 580, 540 ) );
        points7.add( new Point( 580, 570 ) );
        points7.add( new Point( 550, 585 ) );
        points7.add( new Point( 520, 570 ) );

        // Cada llista de punts (points5, points6 i points7) són les formes / figures dels diferents lakes.
        Lake covadonga = new Lake(points5);
        Lake khao = new Lake(points6);
        Lake pang = new Lake(points7);
        
        // Cada llista de punts (points1, points2, points3 i points4) és un país diferent. 
        // A més, cada país té un nom, una capital i diferents lakes i ciutats associats.
        Country espanya = new Country(points1, "Espanya", madrid);
        espanya.addCity(barcelona);
        espanya.addCity(pontevedra);
        espanya.addCity(malaga);
        espanya.addCity(madrid);
        espanya.addLake(covadonga);

        Country tailandia = new Country(points2, "Tailandia", bangkok);
        tailandia.addCity(bangkok);
        tailandia.addCity(huahin);
        tailandia.addCity(pai);
        tailandia.addLake(khao);
        tailandia.addLake(pang);

        Country eeuu = new Country(points3, "EEUU", washingtonDC);
        eeuu.addCity(washingtonDC);
        eeuu.addCity(miami);

        Country cuba = new Country(points4, "Cuba", laHabana);
        cuba.addCity(laHabana);
        
        // Imprimim les àrees dels diferents països.
        System.out.println( "Àrea d'Espanya: " + espanya.getArea() + " km^2 -> hexàgon irregular.");
        System.out.println( "Àrea de Tailandia: " + tailandia.getArea() + " km^2 -> pentàgon irregular.");
        System.out.println( "Àrea d'EEUU: " + eeuu.getArea() + " km^2 -> quadrat.");
        System.out.println( "Àrea de Cuba: " + cuba.getArea() + " km^2 -> triangle equilàter.");

        //La llista countries1 conté la espanya.
        LinkedList< Country > countries1 = new LinkedList< Country >();
        countries1.add(espanya);

        // La llista countries2 conté EEUU i Cuba.
        LinkedList< Country > countries2 = new LinkedList< Country >();
        countries2.add(eeuu);
        countries2.add(cuba);

        // La llista countries3 conté Tailandia.
        LinkedList< Country > countries3 = new LinkedList< Country >();
        countries3.add(tailandia);
        
        // Cada llista de countries és un continent diferent.
        Continent continent1 = new Continent(countries1);
        Continent continent2 = new Continent(countries2);
        Continent continent3 = new Continent(countries3);
        
        // Imprimim les àrees dels diferents continents.
        System.out.println("Continent 1 = Europa (Espanya).");
        System.out.println( "Àrea del continent 1: " + continent1.getTotalArea() + " km^2.");
        System.out.println("Continent 2 = Amèrica del Nord (EEUU i Cuba).");
        System.out.println( "Àrea del continent 2: " + continent2.getTotalArea() + " km^2.");
        System.out.println("Continent 3 = Àsia (Tailandia).");
        System.out.println( "Àrea del continent 3: " + continent3.getTotalArea() + " km^2.");

        // La llista continents conté els 3 diferents continents (continent1, continent2 i continent3).
        LinkedList< Continent > continents = new LinkedList<Continent>();
        continents.add(continent1);
        continents.add(continent2);
        continents.add(continent3);

        // Creació llista de punts points8 (figura --> hexàgon irregular amb vora i farcit blaus).
        LinkedList< Point > points8 = new LinkedList< Point >();
        points8.add( new Point( 380, 330 ) );
        points8.add( new Point( 520, 400 ) );
        points8.add( new Point( 660, 330 ) );
        points8.add( new Point( 660, 440 ) );
        points8.add( new Point( 520, 500 ) );
        points8.add( new Point( 380, 440 ) );

        // Creació llista de punts points9 (figura --> triangle regular amb vora i farcit blaus).
        LinkedList< Point > points9 = new LinkedList< Point >();
        points9.add( new Point( 410, 780 ) );
        points9.add( new Point( 485, 650 ) );
        points9.add( new Point( 335, 650 ) );

        // Cada llista de punts (points8 i points9) són les formes / figures dels diferents oceans.
        Ocean ocean1 = new Ocean(points8);
        Ocean ocean2 = new Ocean(points9);

        // La llista oceans conté els 2 diferents oceans (ocean1 i ocean2).
        LinkedList< Ocean > oceans = new LinkedList<Ocean>();
        oceans.add(ocean1);
        oceans.add(ocean2);

        // La llista de continents i la llista d'oceans pertanyen a un mateix món.
        world = new World(continents, oceans);
    }

    private void initComponents() {
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
    }

    public void paint( java.awt.Graphics g ) {
        super.paint( g );
        world.drawW(g); // Cridem a la funció drawW() (creada a World) per poder mostrar per pantalla tot el món.
    }

}

package practica2;

import java.util.LinkedList;


public class MyMap extends javax.swing.JPanel {

    // Atribut
    private World world;

    public MyMap() {
        initComponents();

        // Creació llista de points1 (figura --> hexàgon irregular).
        LinkedList< Point > points1 = new LinkedList< Point >();
        points1.add( new Point( 100, 190 ) );
        points1.add( new Point( 240, 100 ) );
        points1.add( new Point( 380, 190 ) );
        points1.add( new Point( 380, 290 ) );
        points1.add( new Point( 240, 380 ) );
        points1.add( new Point( 100, 290 ) );

        // Creació llista de points2 (figura --> pentàgon irregular).
        LinkedList< Point > points2 = new LinkedList< Point >();
        points2.add( new Point( 500, 540 ) );
        points2.add( new Point( 580, 500 ) );
        points2.add( new Point( 660, 540 ) );
        points2.add( new Point( 610, 700 ) );
        points2.add( new Point( 550, 700 ) );
        
        // Creació llista de points3 (figura --> quadrat).
        LinkedList< Point > points3 = new LinkedList< Point >();
        points3.add( new Point( 500, 100 ) );
        points3.add( new Point( 700, 100 ) );
        points3.add( new Point( 700, 300 ) );
        points3.add( new Point( 500, 300 ) );
        
        // Creació llista de points4 (figura --> triangle equilàter).
        LinkedList< Point > points4 = new LinkedList< Point >();
        points4.add( new Point( 300, 500 ) );
        points4.add( new Point( 375, 630 ) );
        points4.add( new Point( 225, 630 ) );
        
        // Cada llista de punts és una regió diferent.
        PolygonalRegion region1 = new PolygonalRegion( points1 );
        PolygonalRegion region2 = new PolygonalRegion( points2 );
        PolygonalRegion region3 = new PolygonalRegion( points3 );
        PolygonalRegion region4 = new PolygonalRegion( points4 );
        
        // Imprimim les àrees de les diferents regions.
        System.out.println( "Àrea de la regió 1: " + region1.getArea() + " km^2 -> hexàgon irregular.");
        System.out.println( "Àrea de la regió 2: " + region2.getArea() + " km^2 -> pentàgon irregular.");
        System.out.println( "Àrea de la regió 3: " + region3.getArea() + " km^2 -> quadrat.");
        System.out.println( "Àrea de la regió 4: " + region4.getArea() + " km^2 -> triangle equilàter.");

        // La llista countries1 conté la regió 1.
        LinkedList< PolygonalRegion > countries1 = new LinkedList< PolygonalRegion >();
        countries1.add(region1);

        // La llista countries2 conté la regió 3 i 4.
        LinkedList< PolygonalRegion > countries2 = new LinkedList< PolygonalRegion >();
        countries2.add(region3);
        countries2.add(region4);

        // La llista countries3 conté la regió 2.
        LinkedList< PolygonalRegion > countries3 = new LinkedList< PolygonalRegion >();
        countries3.add(region2);
        
        // Cada llista de countries és un continent diferent.
        Continent continent1 = new Continent(countries1);
        Continent continent2 = new Continent(countries2);
        Continent continent3 = new Continent(countries3);
        
        // Imprimim les àrees dels diferents continents.
        System.out.println("Continent 1 = Hexàgon irregular.");
        System.out.println( "Àrea del continent 1: " + continent1.getTotalArea() + " km^2.");
        System.out.println("Continent 2 = Quadrat + Triangle equilàter.");
        System.out.println( "Àrea del continent 2: " + continent2.getTotalArea() + " km^2.");
        System.out.println("Continent 3 = Pentàgon irregular.");
        System.out.println( "Àrea del continent 3: " + continent3.getTotalArea() + " km^2.");

        // La llista continents conté els 3 diferents continents (continent1, continent2 i continent3).
        LinkedList< Continent > continents = new LinkedList<Continent>();
        continents.add(continent1);
        continents.add(continent2);
        continents.add(continent3);
        
        // La llista de continents pertany a un mateix món.
        world = new World(continents);
    }

    private void initComponents() {
        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1000, Short.MAX_VALUE)
        );
    }

    public void paint( java.awt.Graphics g ) {
        super.paint( g );
        world.drawW(g); // Cridem a la funció drawW() (creada a World) per poder mostrar per pantalla tot el món.
    }

}
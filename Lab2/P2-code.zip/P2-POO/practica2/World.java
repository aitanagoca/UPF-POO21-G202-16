package practica2;

import java.util.LinkedList;
import java.awt.Graphics;

public class World {
    private LinkedList<Continent> conts;

    // Constructor
    public World(LinkedList<Continent> conts){
        this.conts = conts;
    }

    // Cridem a la funció drawC() (creada a Continent) per, mitjançant la iteració, mostrar per pantalla els diferents continents que pertanyen a un mateix món.

    public void drawW(Graphics g) {
        int nContinents = conts.size();
        for(int i = 0; i < nContinents; i++){
            conts.get(i).drawC(g);
        }
    }    
}
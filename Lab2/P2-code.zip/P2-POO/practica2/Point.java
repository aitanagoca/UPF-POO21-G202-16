package practica2;

public class Point {
    private double x;
    private double y;

    // Constructor
    public Point(double x, double y){
        this.x = x;
        this.y = y;
    }

    // Getters

    // Obtenim el valor (double) de x.

    public double getX(){
        return this.x;
    }
    
    // Obtenim el valor (double) de y.

    public double getY(){
        return this.y;
    }

    // Setters

    // Establim el valor (double) de x. 

    public void setX(double x){
        this.x = x;
    }

    // Establim el valor (double) de y. 

    public void setY(double y){
        this.y = y;
    }
}
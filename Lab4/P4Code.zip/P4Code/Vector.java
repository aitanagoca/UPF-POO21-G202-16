
public class Vector extends Point{

    // Constructor
    public Vector (double x, double y){
        super(x, y);
    }

    /* Donat un vector general i un passat per paràmetre, mitjançant la fórmula proporcionada en el lab, 
    calculem el producte creuat entre el genaral i el passat per paràmetre, en aquest ordre. */

    public double crossProduct(Vector u) {
        double product = (getX() * u.getY()) - (getY() * u.getX());
        return product;
    }
}

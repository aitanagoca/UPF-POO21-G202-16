
import java.awt.*;
import java.awt.Graphics;

// Creació classe asbtracta Region. -> Una classe abstracta utilitza mètodes abstractes per agrupar el comportament comú.
abstract public class Entity {
	
	// Els atributs amb visibilitat protegida són accessibles des de la subclasse.
	protected Color lineColor;

	// Constructor
	public Entity( Color lcinit ) {
		lineColor = lcinit;
	}

	// Mètodes abstractes. -> Per teoria, han de ser públics.
	abstract public void draw(Graphics g);
	abstract public void translate( int dx, int dy );
	
}

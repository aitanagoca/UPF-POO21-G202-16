import java.awt.Color;
import java.util.LinkedList;

public class RectangularRegion extends PolygonalRegion{

    // Constructor
    public RectangularRegion(LinkedList<Point> points, Color lineColor, Color fillColor) {
        super(points, lineColor, fillColor);
    }

    /* Donats dos punts (els que formen una diagnonal) d'una regió rectangular, 
    podem trobar els altres dos  mitjançant l'expressió (x1,y1),(x1,y2),(x2,y2),(x2,y1).
    Per tant, obtenim els punts de la llista points mitjançant get() i trobem els altres dos mitjançant la fórmula anterior.
    Netegem els punts de la llista points amb clear(), i afegim, per ordre, els punts de la nostra regió rectangular.*/

    public void getPoints(LinkedList<Point> points) {
        Point p1 = points.get(0);
        Point p3 = points.get(1);
        Point p2 = new Point(p1.getX(), p3.getY());
        Point p4 = new Point(p3.getX(), p1.getY());

        points.clear();
        points.add(p1);
        points.add(p2);
        points.add(p3);
        points.add(p4); 
    }

    /* Cridem a la funció getPoint(), creada en aquesta classe, per obtenir els altres dos punts de la RectangularRegion.
    També cridem a getArea(), creada a PolygonalRegion, mitjançant un super, 
    ja que estem utilitzant una funció de la superclasse, i un override per redefinir el mètode.*/

    public double getArea() {
        getPoints(points);
        return super.getArea();
    }
}

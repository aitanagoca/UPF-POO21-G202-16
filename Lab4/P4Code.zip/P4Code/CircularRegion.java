import java.awt.Color;

public class CircularRegion extends EllipsoidalRegion{

    // Constructor
    public CircularRegion(Point c, double r1, Color lineColor, Color fillColor) {
        super(c, r1, r1, lineColor, fillColor);
    }

    // Cridem a la funció getArea(), creada a EllipsoidalRegion, mitjançant un super, ja que estem utilitzant una funció de la superclasse.

    public double getArea() {
        return super.getArea();
    }
}

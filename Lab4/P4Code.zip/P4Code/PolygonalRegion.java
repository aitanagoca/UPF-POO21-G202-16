
import java.util.LinkedList;
import java.awt.Graphics;
import java.awt.Color;

public class PolygonalRegion extends Region{
    
    protected LinkedList<Point> points;

    // Constructor
    public PolygonalRegion(LinkedList<Point> points, Color lineColor, Color fillColor) {
        super(lineColor, fillColor);
        this.points = points;
    }

    /* Utilitzant la fórmula de l'àrea proporcionada en el lab anterior, calculem l'àrea a partir de les coordenades donades. 
    Tal i com indica la fórmula, iterem amb el valor de j anterior al de i. Finalment, fem el valor absolut (ja que tractem amb àrees positives), i dividim entre 2. 
    Fem override per redefinir el mètode. */

    @Override
    public double getArea() {
        
        double area = 0;
        int n = points.size();
        int j = n - 1;
        for (int i = 0; i < n; i++) {
            area += (points.get(j).getX() + points.get(i).getX()) * (points.get(j).getY() - points.get(i).getY());
            j = i;
        }
        return Math.abs(area / 2);
    }

    /* Separem la llista de punts (points) i creem un array de coordenades x i una altre de coordenades y 
    (iterem per introduir un per un els diferents valors de x i y dins l'array).
    Seguidament, podem cridar a la funció de drawPolygon() de Graphics i passar-li per paràmetre els dos arrays 
    creats i el número de punts de la llista de points, i a la funció fillPolygon() amb els mateixos paràmetres. 
    Això ens permetrà mostrar per pantalla la regió que nosaltres volguem tot establint el color de vora  i el color de "relleno"
    amb la crida a la funció setColor() en el moment oportú. 
    Fem override per redefinir el mètode. */

    @Override
    public void draw(Graphics g) {
        int nPoints = points.size();
        int xPoints[] = new int[nPoints];
        int yPoints[] = new int[nPoints];

        for (int i = 0; i < points.size(); i++) {
            xPoints[i] = (int) points.get(i).getX();
            yPoints[i] = (int) points.get(i).getY();
        }
        g.setColor(lineColor);
        g.drawPolygon(xPoints, yPoints, nPoints);
        g.setColor(fillColor);
        g.fillPolygon(xPoints, yPoints, nPoints);
    }

    /* Obtenim el número de punts que conté la llista points.
    Utilitzant la fórmula de isPointInside proporcionada en el lab ((q2 − q1) × (p − q1)), 
    primer de tot ho aplicarem a l'últim punt de la llista amb el primer, ja que sinó, ens donaria un error de range.
    Seguidament entrem en un bucle per aplicar la fórmula als punts, primer i segon, segon i tercer, ..., fins a 
    penúltim i últim. Per cada expressió calculada (equation2), la multipliquem per l'expressió inicialment calculada
    (euqation1), si són de diferent signe, serà negatiu, per tant el punt no està dins de la regió. Si tots els signes són iguals,
    retornarà true i signifoca que el punt estarà dins la regió.
    Fem override per redefinir el mètode. */

    @Override
    public boolean isPointInside(Point p) {
        int nPoints = points.size();
        
        Point q1 = points.get(nPoints-1);
        Point q2 = points.get(0);

        Vector dif1 = q2.difference(q1);
        Vector dif2 = p.difference(q1);
        double equation1 = dif1.crossProduct(dif2);
        
        for(int i=0; i < nPoints-1; i++){
            q1 = points.get(i);
            q2 = points.get(i+1);
            dif1 = q2.difference(q1);
            dif2 = p.difference(q1);
            double equation2 = dif1.crossProduct(dif2); 
                
            if (equation1 * equation2 < 0) {
                return false;
            }
        }
        return true;
    }

    /* Donats els punts per crear un polígon, cridem a la funció translate, creada a Point, 
    per moure els diferents punts que composen un polígon. 
    Fem override per redefinir el mètode. */

    @Override
    public void translate(int dx, int dy) {
        for(int i = 0; i < points.size(); i++){
            points.get(i).translate(dx, dy);
        }
    }
}

import java.awt.Graphics;
import java.awt.Color;

// Creació classe asbtracta Region. -> Una classe abstracta utilitza mètodes abstractes per agrupar el comportament comú.
public abstract class Region extends Entity{
    
    // Els atributs amb visibilitat protegida són accessibles des de la subclasse.
    protected Color fillColor;

    // Constructor
    public Region(Color lineColor, Color fillColor) {
        super(lineColor);
        this.fillColor = fillColor;
    }
    
    // Mètodes abstractes. -> Per teoria, han de ser públics.
    public abstract double getArea();
    public abstract void draw(Graphics g);
    public abstract boolean isPointInside(Point p);
    public abstract void translate(int dx, int dy);
}
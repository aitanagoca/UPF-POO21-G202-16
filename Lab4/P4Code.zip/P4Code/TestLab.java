import java.util.LinkedList;
import java.awt.Color;

public class TestLab {
    public static void main(String[] args) {
        
        // Creació d'una EntityDrawer per poder mostrar per pantalla les regions que formin part d'aquesta.
        EntityDrawer draw1 = new EntityDrawer();

        // Creació llista de punts p1 (figura --> rectangle)
        LinkedList<Point> p1 = new LinkedList<Point>();
        p1.add(new Point(10,10));
        p1.add(new Point(110,510));

        // Creació de RectangularRegion rectangle, amb les seves coordenades, color de vora i color de "relleno".
        RectangularRegion rectangle = new RectangularRegion(p1, Color.magenta, Color.blue);
        // Imprimim l'àrea del rectangle.
        System.out.println("\nArea of the Rectangular Region: " + rectangle.getArea() + " u^2.");
        // Afegim la regió rectangular a la EntityDrawer per poder dibuixar-la.
        draw1.addDrawable(rectangle);

        // Creació de dos punts aleatoris.
        Point testPoint1 = new Point(10,300);
        Point testPoint2 = new Point(111,300);
        // Mirem si els punts creats pertanyen o no al rectangle (pertany = true, no pertany = false).
        System.out.println("Point (" + testPoint1.getX() + "," + testPoint1.getY() + ") is in the rectangle: " + rectangle.isPointInside(testPoint1) + ".");
        System.out.println("Point (" + testPoint2.getX() + "," + testPoint2.getY() + ") is in the rectangle: " + rectangle.isPointInside(testPoint2) + ".");

        // Creació llista de punts p2 (figura --> triangle)
        LinkedList<Point> p2 = new LinkedList<Point>();
        p2.add(new Point(300, 50));
        p2.add(new Point(500, 200));
        p2.add(new Point(300, 250));

        // Creació de TriangularRegion triangle, amb les seves coordenades, color de vora i color de "relleno".
        TriangularRegion triangle = new TriangularRegion(p2, Color.green, Color.gray);
        // Imprimim l'àrea del triangle.
        System.out.println("\nArea of the Triangular Region: " + triangle.getArea() + " u^2.");
        // Afegim la regió triangular a la EntityDrawer per poder dibuixar-la.
        draw1.addDrawable(triangle);

        // Creació de dos punts més aleatoris.
        Point testPoint3 = new Point(350,150);
        Point testPoint4 = new Point(250,100);
        // Mirem si els punts creats pertanyen o no al triangle (pertany = true, no pertany = false).
        System.out.println("Point (" + testPoint3.getX() + "," + testPoint3.getY() + ") is in the triangle: " + triangle.isPointInside(testPoint3) + ".");
        System.out.println("Point (" + testPoint4.getX() + "," + testPoint4.getY() + ") is in the triangle: " + triangle.isPointInside(testPoint4) + ".\n");

        // Creació de dos radis (r1 i r2) i un centre (centre 1) (figura --> ellipsoide).
        // Creació d'un radi (r1) i un centre (centre2) (figura --> circle).
        double r1 = 100;
        double r2 = 300;
        Point centre1 = new Point(150, 150);
        Point centre2 = new Point(300, 300);

        // Creació de EllipsoidalRegion ellipsoide, amb el seu centre, els seus dos radis, color de vora i color de "relleno".
        EllipsoidalRegion ellipsoide = new EllipsoidalRegion(centre1, r1, r2, Color.black, Color.green);
        // Imprimim l'àrea de l'elipse.
        System.out.println("\nArea of the Ellipsoidal Region: " + ellipsoide.getArea() + " u^2.");
        // Afegim la regió elipsoidal a la EntityDrawer per poder dibuixar-la.
        draw1.addDrawable(ellipsoide);

        // Creació de dos punts més aleatoris.
        Point testPoint5 = new Point(170, 250);
        Point testPoint6 = new Point(250, 350);
        // Mirem si els punts creats pertanyen o no a l'elipse (pertany = true, no pertany = false).
        System.out.println("Point (" + testPoint5.getX() + "," + testPoint5.getY() + ") is in the ellipse: " + ellipsoide.isPointInside(testPoint5) + ".");
        System.out.println("Point (" + testPoint6.getX() + "," + testPoint6.getY() + ") is in the ellipse: " + ellipsoide.isPointInside(testPoint6) + ".\n");
        
        // Creació de CircularRegion circle, amb el seu centre, els seus radi, color de vora i color de "relleno".
        CircularRegion circle = new CircularRegion(centre2, r1, Color.blue, Color.magenta);
        // Imprimim l'àrea de la circumferència.
        System.out.println("\nArea of the Circular Region: " + circle.getArea() + " u^2.");
        // Afegim la regió circular a la EntityDrawer per poder dibuixar-la.
        draw1.addDrawable(circle);

        // Creació d'un punt més aleatori.
        Point testPoint7 = new Point(400, 300);
        // Mirem si els punts creats pertanyen o no a la circumferència (pertany = true, no pertany = false).
        System.out.println("Point (" + testPoint7.getX() + "," + testPoint7.getY() + ") is in the circle: " + circle.isPointInside(testPoint7) + ".");
        System.out.println("Point (" + centre1.getX() + "," + centre1.getY() + ") is in the circle: " + circle.isPointInside(centre1) + ".\n");

    }
}

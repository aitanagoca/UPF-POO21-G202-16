import java.awt.Color;
import java.util.LinkedList;

public class TriangularRegion extends PolygonalRegion{

    // Constructor
    public TriangularRegion(LinkedList<Point> points, Color lcinit, Color fillColor) {
        super(points, lcinit, fillColor);
    }

    /* Cridem a la funció getArea(), creada a PolygonalRegion, mitjançant un super, 
    ja que estem utilitzant una funció de la superclasse, i un override per redefinir el mètode.*/
   
    public double getArea() {
        return super.getArea();
    }
}

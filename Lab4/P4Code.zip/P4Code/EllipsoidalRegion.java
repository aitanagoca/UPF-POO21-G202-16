import java.awt.Color;
import java.awt.Graphics;

public class EllipsoidalRegion extends Region{
    
    private Point c;
    private double r1, r2;

    // Constructor
    public EllipsoidalRegion(Point c, double r1, double r2, Color lineColor, Color fillColor) {
        super(lineColor, fillColor);
        this.c = c;
        this.r1 = r1;
        this.r2 = r2;
    }

    /* Utilitzant la fórmula de l'àrea A = pi * radi1 * radi2, calculem l'àrea. 
    Per no tenir un gran nombre de decimals, arrodonim amb la funció round() a 4 decimals. 
    Fem override per redefinir el mètode. */

    @Override
    public double getArea() {
        double area = Math.PI * (r1/2) * (r2/2);
        return Math.round(area*10000.0)/10000.0;
    }

    /* Obtenim les coordenades x i y del centre de l'elipsoide, les castejem a int i les emmagatzemem en unes
    variables (pointX i pointY).
    Seguidament, cridem a la funció setColor(), per establir el color de vora, i a drawOval(), tot passant-li 
    per paràmetre les dues variables anterior i els dos radis (castejats), per dibuixar l'elipsoide.
    Així mateix, cridem a la funció setColor(), per establir el color de "relleno", i a fillOval() per 
    omplir un oval limitat pel rectangle especificat amb el color actual.
    Fem override per redefinir el mètode. */

    @Override
    public void draw(Graphics g) {
        int pointX = (int) c.getX();
        int pointY = (int) c.getY();

        g.setColor(lineColor);
        g.drawOval(pointX, pointY, (int) r1, (int) r2); 
        g.setColor(fillColor); 
        g.fillOval(pointX, pointY, (int) r1, (int) r2);
    }

    /* Utilitzant la fórmula de isPointInside proporcionada en el lab, calculem la suma.
    Si és més petit o igual que 1, significa que el punt està dins la regió elipsoidal, en cas contrari,
    el punt es troba fora i per tant, retornem false.
    Fem override per redefinir el mètode. */

    @Override
    public boolean isPointInside (Point p) {
        double beforesum = (Math.pow((p.getX() - c.getX()), 2)) / (Math.pow(r1, 2));
        double aftersum = (Math.pow((p.getY() - c.getY()), 2)) / (Math.pow(r2, 2));
        double equation = beforesum + aftersum;
        if(equation <= 1){
            return true;
        }
        return false;
    }

    /* Obtenim les coordenades del centre de l'elipsoide. 
    Mitjançant la funció setX() i setY(), implementades a la classe Point,li sumem la distància de translació desitjada.
    Fem override per redefinir el mètode. */

    @Override
    public void translate(int dx, int dy) {
        double px = c.getX();
        double py = c.getY();
        c.setX(px + dx);
        c.setY(py + dy); 
    }
}

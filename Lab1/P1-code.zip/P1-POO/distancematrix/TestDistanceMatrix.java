package distancematrix;

public class TestDistanceMatrix {
    public static void main(String[] args){

        //Creem la variable de matrix que volem provar.
        DistanceMatrix matrix = new DistanceMatrix();
        
        //Provem la funció (mètode) addCity, per seguidament provar diferents mètodes, amb 4 ciutats amb coordenades inventades.
        matrix.addCity(3, 7, "Barcelona");
        matrix.addCity(5, 2, "Pontevedra");
        matrix.addCity(0, 0, "Madrid");
        matrix.addCity(4, 6, "Valencia");

        //Provem el getter getNoOfCities per obtenir el número de ciutats afegides.
        int size = matrix.getNoOfCities();
        System.out.println("En la matriu hi ha " + size + " ciutats.");
        
        //Provem el getter getDistance per obtenir la distància entre dos punts, en aquest cas, dues ciutats.
        //També provem el getCityName per obtenir els noms de les diferents ciutats per imprimir-les.
        double distance = matrix.getDistance(2, 1);
        System.out.println("La distància entre " + matrix.getCityName(2) + " i " + matrix.getCityName(1) + " és de: " + distance + " km.");

        //Provem la funció (mètode) createDistanceMatrix per omplir la matriu creada amb les distàncies entre les diferents ciutats.
        //Provem el setter getMatrix  per establir els valors de la matriu creada.
        matrix.createDistanceMatrix();
        System.out.println("La matriu creada és: ");
        System.out.println(matrix.setMatrix());
        

    }
}

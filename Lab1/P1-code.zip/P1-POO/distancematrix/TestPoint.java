package distancematrix;
public class TestPoint {
    public static void main(String[] args){
        
        //Creem 4 ciutats amb coordenades inventades.
        GeometricPoint barcelona = new GeometricPoint(3, 7, "Barcelona");
        GeometricPoint pontevedra = new GeometricPoint(5, 2, "Pontevedra");
        GeometricPoint madrid = new GeometricPoint(0, 0, "Madrid");
        GeometricPoint valencia = new GeometricPoint(4, 6, "València");

        //Provem la funció d'impimir un punt.
        System.out.println("Les coordenades de les diferents ciutats són:");
        barcelona.printPoint();
        pontevedra.printPoint();
        madrid.printPoint();
        valencia.printPoint();

        //Provem la funció distancePoint per trobar la distància entre dos punts (dues ciutats).
        System.out.println("La distància entre Barcelona i València és de: " + barcelona.distancePoint(pontevedra) + " km.");
        System.out.println("La distància entre Madrid i València és de: " + madrid.distancePoint(valencia) + " km.");

        //Provem els setters i getters. 
        //Establim uns nous valors (coordenades) per la ciutat de Barcelona, i li canviem el nom, per imprimir-ho seguidament.
        double valueX = barcelona.getX() + 3;
        double valueY = barcelona.getY() + 3;
        barcelona.setX(valueX);
        barcelona.setY(valueY);
        barcelona.setName("Tarragona");
        System.out.println("El nou nom de la ciutat de Barcelona és: " + barcelona.getName());
        System.out.println("Les seves noves coordenades són: ");
        barcelona.printPoint();
    }
}

package distancematrix;

//La funció main (implementada al document) crea una variable matriu per mostrar-la per pantalla amb la funció DisplayMatrix. 
public class TestDisplayMatrix {
    public static void main(String[] args){
        DistanceMatrix matrix = new DistanceMatrix();
        DisplayMatrix display = new DisplayMatrix(matrix);
        display.setVisible(true);
    }
}

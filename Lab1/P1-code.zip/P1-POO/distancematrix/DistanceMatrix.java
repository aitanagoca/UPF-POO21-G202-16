package distancematrix;
import java.util.LinkedList;

public class DistanceMatrix implements Matrix {
    private LinkedList<GeometricPoint> cities;
    private LinkedList<LinkedList<Double>> matrix;

    //Constructor
    public DistanceMatrix(){
        this.cities = new LinkedList<GeometricPoint>();
        this.matrix = new LinkedList<LinkedList<Double>>();
    }

    //Methods

    //Establim els valors (double) de la matriu (llista d'una llista).
    public LinkedList<LinkedList<Double>> setMatrix(){
        return this.matrix;
    }

    //Obtenim el String name de la ciutat indicada.
    public String getCityName(int index){
        return cities.get(index).getName();
    }

    //Obtenim el número de ciutats que afegim a l'hora de provar el nostre codi.
    public int getNoOfCities(){
        return cities.size();
    }

    //Obtenim la distància entre dues ciutats cridant a la funció del fitxer GeometricPoint, distancePoint.
    public double getDistance(int index1, int index2){
        return cities.get(index1).distancePoint(cities.get(index2));
    }

    //Afegim una ciutat, mitjançant la creació d'un nou GeometricPoint amb les seves coordenades i el seu nom, en la nostra llista de ciutats.
    public void addCity(double X, double Y, String name){
        GeometricPoint noUsed = new GeometricPoint(X, Y, name);
        cities.add(noUsed);
    }

    //Obtenint el número de ciutats, realitzem dos loops per afegir les diferents distàncies entre les diferents ciutats a la matriu.
    public void createDistanceMatrix(){
        LinkedList<LinkedList<Double>> distanceMatrix = new LinkedList<LinkedList<Double>>();
        int numCities = getNoOfCities();
        for(int i = 0; i < numCities; i++){
            LinkedList<Double> distanceList = new LinkedList<Double>();
            for(int j = 0; j < numCities; j++){
                distanceList.add(getDistance(i, j));
            }
            distanceMatrix.add(distanceList);
        }
        matrix = distanceMatrix;
    }
}

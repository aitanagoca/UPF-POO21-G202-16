package distancematrix;

public class GeometricPoint{
    private double X;
    private double Y;
    private String name;

    //Constructor
    public GeometricPoint(double X, double Y, String name){
        this.X = X;
        this.Y = Y;
        this.name = name;
    }

    //Methods
    
    //Obtenim el valor (double) de X.
    public double getX(){
        return this.X;
    }

    //Obtenim el valor (double) de Y.
    public double getY(){
        return this.Y;
    }

    //Obtenim el String name.
    public String getName(){
        return this.name;
    }
    
    //Establim el valor (double) de X. 
    public void setX(double X){
        this.X = X;
    }

    //Establim el valor (double) de Y.
    public void setY(double Y){
        this.Y = Y;
    }

    //Establim el name.
    public void setName(String name){
        this.name = name;
    }
    
    //Mitjançant la fórmula de la distància entre dos punts, retornem la distància entre dos punts.
    public double distancePoint(GeometricPoint point){
        double distance = (Math.sqrt(Math.pow((X - point.X), 2) + Math.pow((Y - point.Y), 2)));
        return distance;
    }

    //Imprimim les coordenades del punt corresponent.
    public void printPoint(){
        System.out.println(name + " = (" + X + ',' + Y + ')');
    }
}